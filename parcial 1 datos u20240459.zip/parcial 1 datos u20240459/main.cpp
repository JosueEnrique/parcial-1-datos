//Josue Enriique Moreno U20240459
//Parcial 1 Estructura de Datos
//autoevaluacion 10/10

#include <iostream>
#include <vector>
#include <list>
#include <algorithm>
#include <string>
#include <iomanip>

int main() {
    int numDias;
    std::cout << " REGISTRO DE TEMPERATURAS  " << std::endl;
    std::cout << "Cuántos días se registrarán? ";
    std::cin >> numDias;
    std::vector<float> temperaturas(numDias);
    
    std::cout << "\nIngrese las temperaturas para cada día:" << std::endl;
    for (int i = 0; i < numDias; i++) {
        std::cout << "Día " << (i + 1) << ": ";
        std::cin >> temperaturas[i];
    }
    
    std::cout << "\n=== TEMPERATURAS REGISTRADAS ===" << std::endl;
    float* ptr = &temperaturas[0]; 
    float suma = 0.0f;

    for (int i = 0; i < numDias; i++) {
        std::cout << "Día " << (i + 1) << ": " << std::fixed << std::setprecision(1) 
                  << *(ptr + i) << "°C" << std::endl;
        suma += *(ptr + i);
    }

    float promedio = suma / numDias;
    std::cout << "\nTemperatura promedio: " << std::fixed << std::setprecision(2) 
              << promedio << "°C" << std::endl;

    float tempBuscar;
    std::cout << "\n=== BUSCAR TEMPERATURA ===" << std::endl;
    std::cout << "Ingrese la temperatura que desea buscar: ";
    std::cin >> tempBuscar;
    
    bool encontrada = false;
    int posicion = -1;

    for (int i = 0; i < numDias; i++) {
        if (temperaturas[i] == tempBuscar) {
            encontrada = true;
            posicion = i;
            break;
        }
    }
    
    if (encontrada) {
        std::cout << "Temperatura " << tempBuscar << "°C encontrada en el día " 
                  << (posicion + 1) << " (posición " << posicion << ")" << std::endl;
    } else {
        std::cout << "La temperatura " << tempBuscar 
                  << "°C no existe en el registro." << std::endl;
    }
    std::cout << "\n=== TEMPERATURAS ORDENADAS ===" << std::endl;
    std::vector<float> temperaturasOrdenadas = temperaturas;

    std::sort(temperaturasOrdenadas.begin(), temperaturasOrdenadas.end());
    std::cout << "Temperaturas ordenadas de menor a mayor:" << std::endl;
    for (size_t i = 0; i < temperaturasOrdenadas.size(); i++) {
        std::cout << (i + 1) << ". " << std::fixed << std::setprecision(1) 
                  << temperaturasOrdenadas[i] << "°C" << std::endl;
    }
    

    std::cout << "\n=== GESTIÓN DE EQUIPOS ===" << std::endl;
    

    std::list<std::string> equipos;
    
 
    equipos.push_back("Termómetro");
    equipos.push_back("sol");
    equipos.push_back("Termómetro 2");
    equipos.push_back("temp");
    equipos.push_back("calor");
    
    std::cout << "Lista inicial de equipos:" << std::endl;
    
    int contador = 1;
    for (auto it = equipos.begin(); it != equipos.end(); ++it) {
        std::cout << contador << ". " << *it << std::endl;
        contador++;
    }
        std::string equipoBuscar;
    std::cout << "\nIngrese el nombre del equipo que desea buscar: ";
    std::cin.ignore(); 
    std::getline(std::cin, equipoBuscar);
    
    auto encontrado = std::find(equipos.begin(), equipos.end(), equipoBuscar);
    
    if (encontrado != equipos.end()) {
        std::cout << "Equipo '" << equipoBuscar << "' encontrado en la lista." << std::endl;
    } else {
        std::cout << "Equipo '" << equipoBuscar << "' no encontrado en la lista." << std::endl;
    }
    
    std::cout << "\n--- Ordenando equipos alfabéticamente ---" << std::endl;
    equipos.sort();
    
    std::cout << "Lista de equipos ordenada:" << std::endl;
    contador = 1;
    for (auto it = equipos.begin(); it != equipos.end(); ++it) {
        std::cout << contador << ". " << *it << std::endl;
        contador++;
    }
    

    std::string equipoEliminar;
    std::cout << "\nIngrese el nombre del equipo que desea eliminar: ";
    std::getline(std::cin, equipoEliminar);
    
    size_t tamañoAntes = equipos.size();
    equipos.remove(equipoEliminar);
    size_t tamañoDespues = equipos.size();
    
    if (tamañoAntes > tamañoDespues) {
        std::cout << "Equipo '" << equipoEliminar << "' eliminado correctamente." << std::endl;
    } else {
        std::cout << "Equipo '" << equipoEliminar << "' no encontrado para eliminar." << std::endl;
    }
    
    std::cout << "\nLista final de equipos:" << std::endl;
    if (equipos.empty()) {
        std::cout << "La lista está vacía." << std::endl;
    } else {
        contador = 1;
        for (auto it = equipos.begin(); it != equipos.end(); ++it) {
            std::cout << contador << ". " << *it << std::endl;
            contador++;
        }
    }
    
    std::cout << "\n=== PROGRAMA FINALIZADO ===" << std::endl;
    return 0;
}